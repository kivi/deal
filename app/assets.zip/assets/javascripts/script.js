// $(document).ready(function () {
// 
// var inp,def,rate;
// window.onload=function()
// {
// def=1;
// rate=1;
// inp=document.getElementById('val');
// inp.value=def;
// document.getElementById('less').onclick=function()
// {inp.value=Number(document.getElementById('val').value)-rate;}
// document.getElementById('plus').onclick=function()
// {inp.value=Number(document.getElementById('val').value)+rate;}
// }
// 
// $('#soldnumbers span').delay(500).fadeOut(250).fadeIn(250).delay(500).fadeOut(250).fadeIn(250);
// 
// });

